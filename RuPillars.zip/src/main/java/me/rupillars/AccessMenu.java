package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Меню доступа к своей метке (Java): головы игроков, клик выдаёт или забирает доступ. */
public final class AccessMenu implements InventoryHolder {

    private final PillarsPlugin plugin;
    private final String pillarId;
    private final Map<Integer, UUID> slots = new HashMap<>();
    private Inventory inventory;

    private AccessMenu(PillarsPlugin plugin, String pillarId) {
        this.plugin = plugin;
        this.pillarId = pillarId;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private static Component plain(String legacy) {
        return PillarsPlugin.legacy(legacy).decoration(TextDecoration.ITALIC, false);
    }

    public static void open(PillarsPlugin plugin, Player viewer, Pillar p) {
        AccessMenu menu = new AccessMenu(plugin, p.id);
        menu.inventory = Bukkit.createInventory(menu, 54,
                PillarsPlugin.legacy(PillarsPlugin.fill(plugin.raw("access-title"), "%name%", p.name)));

        // Сначала те, у кого доступ уже есть, потом остальные игроки онлайн.
        Map<UUID, OfflinePlayer> players = new LinkedHashMap<>();
        for (UUID u : p.allowed) players.put(u, Bukkit.getOfflinePlayer(u));
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.getUniqueId().equals(p.owner)) continue;
            players.putIfAbsent(online.getUniqueId(), online);
        }

        int slot = 0;
        for (Map.Entry<UUID, OfflinePlayer> e : players.entrySet()) {
            if (slot >= 45) break;
            OfflinePlayer op = e.getValue();
            boolean has = p.allowed.contains(e.getKey());
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(op);
            meta.displayName(plain("&f" + (op.getName() == null ? "?" : op.getName())));
            List<Component> lore = new ArrayList<>();
            lore.add(plain(plugin.raw(has ? "access-has" : "access-hasnt")));
            lore.add(plain(plugin.raw(has ? "access-click-take" : "access-click-give")));
            meta.lore(lore);
            head.setItemMeta(meta);
            menu.inventory.setItem(slot, head);
            menu.slots.put(slot, e.getKey());
            slot++;
        }

        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta bm = back.getItemMeta();
        bm.displayName(plain(plugin.raw("manage-back")));
        back.setItemMeta(bm);
        menu.inventory.setItem(49, back);
        ItemStack info = new ItemStack(Material.PAPER);
        ItemMeta im = info.getItemMeta();
        im.displayName(plain(plugin.raw("access-info")));
        info.setItemMeta(im);
        menu.inventory.setItem(45, info);
        viewer.openInventory(menu.inventory);
    }

    public void click(Player player, int slot) {
        Pillar p = plugin.manager().byId(pillarId);
        if (p == null) {
            player.closeInventory();
            player.sendMessage(plugin.msg("gone"));
            return;
        }
        if (slot == 49) {
            ManageMenu.open(plugin, player);
            return;
        }
        UUID target = slots.get(slot);
        if (target == null) return;
        plugin.applyAccess(player, p, Bukkit.getOfflinePlayer(target), !p.allowed.contains(target));
        open(plugin, player, p);
    }
}
