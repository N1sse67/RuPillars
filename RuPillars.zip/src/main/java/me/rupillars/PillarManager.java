package me.rupillars;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Хранение меток, постройка столбов и телепортация. */
public final class PillarManager {

    private final PillarsPlugin plugin;
    private final File file;
    private final Map<String, Pillar> pillars = new LinkedHashMap<>();
    private final Set<String> blockIndex = new HashSet<>();
    private final Map<UUID, BukkitTask> warmups = new HashMap<>();
    private final Map<UUID, Long> lastTeleport = new HashMap<>();

    public PillarManager(PillarsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    // ---------- настройки ----------

    public List<Material> materials() {
        List<Material> list = new ArrayList<>();
        for (String s : plugin.getConfig().getStringList("blocks")) {
            Material m = Material.matchMaterial(s.trim());
            if (m != null && m.isBlock()) list.add(m);
        }
        if (list.isEmpty()) {
            list.add(Material.CHISELED_STONE_BRICKS);
            list.add(Material.QUARTZ_PILLAR);
            list.add(Material.SEA_LANTERN);
        }
        return list;
    }

    public int height() {
        return materials().size();
    }

    // ---------- загрузка и сохранение ----------

    public void load() {
        pillars.clear();
        blockIndex.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yml.getConfigurationSection("pillars");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            try {
                Pillar p = new Pillar();
                p.id = id;
                p.owner = UUID.fromString(s.getString("owner", ""));
                p.ownerName = s.getString("owner-name", "?");
                p.name = s.getString("name", id);
                p.world = s.getString("world", "world");
                p.bx = s.getInt("bx");
                p.by = s.getInt("by");
                p.bz = s.getInt("bz");
                p.tx = s.getDouble("tx");
                p.ty = s.getDouble("ty");
                p.tz = s.getDouble("tz");
                p.yaw = (float) s.getDouble("yaw");
                p.open = s.getBoolean("open", true);
                pillars.put(id, p);
            } catch (IllegalArgumentException e) {
                plugin.getLogger().warning("data.yml: не удалось прочитать метку " + id);
            }
        }
        reindex();
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Pillar p : pillars.values()) {
            String b = "pillars." + p.id;
            yml.set(b + ".owner", p.owner.toString());
            yml.set(b + ".owner-name", p.ownerName);
            yml.set(b + ".name", p.name);
            yml.set(b + ".world", p.world);
            yml.set(b + ".bx", p.bx);
            yml.set(b + ".by", p.by);
            yml.set(b + ".bz", p.bz);
            yml.set(b + ".tx", p.tx);
            yml.set(b + ".ty", p.ty);
            yml.set(b + ".tz", p.tz);
            yml.set(b + ".yaw", p.yaw);
            yml.set(b + ".open", p.open);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить data.yml: " + e.getMessage());
        }
    }

    private static String key(String world, int x, int y, int z) {
        return world + ";" + x + ";" + y + ";" + z;
    }

    private void reindex() {
        blockIndex.clear();
        // Для чтения индекса берём высоту из конфига; для уже построенных столбов она тоже совпадает.
        int h = height();
        for (Pillar p : pillars.values()) {
            for (int i = 0; i < h; i++) blockIndex.add(key(p.world, p.bx, p.by + i, p.bz));
        }
    }

    // ---------- поиск ----------

    public Pillar atBlock(Block block) {
        if (!blockIndex.contains(key(block.getWorld().getName(), block.getX(), block.getY(), block.getZ()))) return null;
        int h = height();
        for (Pillar p : pillars.values()) {
            if (!p.world.equals(block.getWorld().getName()) || p.bx != block.getX() || p.bz != block.getZ()) continue;
            if (block.getY() >= p.by && block.getY() < p.by + h) return p;
        }
        return null;
    }

    public boolean isPillarBlock(Block block) {
        return blockIndex.contains(key(block.getWorld().getName(), block.getX(), block.getY(), block.getZ()));
    }

    public int count() {
        return pillars.size();
    }

    public Pillar byId(String id) {
        return pillars.get(id);
    }

    public Pillar nearest(Player player, double radius) {
        Pillar best = null;
        double bestDist = radius * radius;
        Location loc = player.getLocation();
        for (Pillar p : pillars.values()) {
            if (!p.world.equals(loc.getWorld().getName())) continue;
            if (!canUse(player, p)) continue;
            double dx = p.bx + 0.5 - loc.getX();
            double dy = p.by - loc.getY();
            double dz = p.bz + 0.5 - loc.getZ();
            double d = dx * dx + dy * dy + dz * dz;
            if (d <= bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    public boolean canUse(Player player, Pillar p) {
        return p.open || p.owner.equals(player.getUniqueId()) || player.hasPermission("rupillars.admin");
    }

    /** Метки, которые игрок видит в меню. */
    public List<Pillar> visibleFor(Player player) {
        List<Pillar> list = new ArrayList<>();
        for (Pillar p : pillars.values()) if (canUse(player, p)) list.add(p);
        list.sort(Comparator.comparing((Pillar p) -> p.name.toLowerCase(Locale.ROOT)));
        return list;
    }

    public List<Pillar> ownedBy(UUID owner) {
        List<Pillar> list = new ArrayList<>();
        for (Pillar p : pillars.values()) if (p.owner.equals(owner)) list.add(p);
        list.sort(Comparator.comparing((Pillar p) -> p.name.toLowerCase(Locale.ROOT)));
        return list;
    }

    public Pillar findOwned(UUID owner, String name) {
        for (Pillar p : pillars.values()) {
            if (p.owner.equals(owner) && p.name.equalsIgnoreCase(name)) return p;
        }
        return null;
    }

    public Pillar findAny(String name) {
        for (Pillar p : pillars.values()) if (p.name.equalsIgnoreCase(name)) return p;
        return null;
    }

    // ---------- создание и удаление ----------

    /** Блок, где будет стоять нижняя часть столба: перед игроком. Возвращает null, если места нет. */
    public Block placementBase(Player player) {
        BlockFace face = player.getFacing();
        Block base = player.getLocation().getBlock().getRelative(face);
        int h = height();
        if (!base.getRelative(BlockFace.DOWN).getType().isSolid()) return null;
        for (int i = 0; i < h; i++) {
            Block b = base.getRelative(0, i, 0);
            if (!b.getType().isAir()) return null;
            if (b.getY() >= b.getWorld().getMaxHeight()) return null;
        }
        return base;
    }

    public Pillar create(Player player, String name, Block base) {
        Pillar p = new Pillar();
        do {
            p.id = Integer.toHexString(new java.util.Random().nextInt(0xFFFFFF) + 0x100000);
        } while (pillars.containsKey(p.id));
        p.owner = player.getUniqueId();
        p.ownerName = player.getName();
        p.name = name;
        p.world = base.getWorld().getName();
        p.bx = base.getX();
        p.by = base.getY();
        p.bz = base.getZ();
        Location loc = player.getLocation();
        p.tx = loc.getX();
        p.ty = loc.getY();
        p.tz = loc.getZ();
        p.yaw = loc.getYaw();

        List<Material> mats = materials();
        for (int i = 0; i < mats.size(); i++) {
            base.getRelative(0, i, 0).setType(mats.get(i), false);
        }
        pillars.put(p.id, p);
        reindex();
        spawnHologram(p);
        save();
        return p;
    }

    private Location hologramLocation(Pillar p, World world) {
        return new Location(world, p.bx + 0.5, p.by + height() + 0.6, p.bz + 0.5);
    }

    private void spawnHologram(Pillar p) {
        if (!plugin.getConfig().getBoolean("hologram", true)) return;
        World world = Bukkit.getWorld(p.world);
        if (world == null) return;
        String text = plugin.getConfig().getString("hologram-text", "&6%name%")
                .replace("%name%", p.name).replace("%owner%", p.ownerName);
        Component component = PillarsPlugin.legacy(text);
        world.spawn(hologramLocation(p, world), TextDisplay.class, td -> {
            td.text(component);
            td.setBillboard(Display.Billboard.CENTER);
            td.setPersistent(true);
        });
    }

    private void removeHologram(Pillar p) {
        World world = Bukkit.getWorld(p.world);
        if (world == null) return;
        Location at = hologramLocation(p, world);
        world.getChunkAt(at);
        for (Entity e : world.getNearbyEntities(at, 1.0, 1.5, 1.0)) {
            if (e instanceof TextDisplay) e.remove();
        }
    }

    /** Убрать столб и запись о метке. */
    public void remove(Pillar p) {
        World world = Bukkit.getWorld(p.world);
        if (world != null) {
            int h = height();
            for (int i = 0; i < h; i++) {
                world.getBlockAt(p.bx, p.by + i, p.bz).setType(Material.AIR, false);
            }
            removeHologram(p);
        }
        pillars.remove(p.id);
        reindex();
        save();
    }

    // ---------- цена в уровнях опыта ----------

    /** Сколько уровней опыта стоит телепорт к метке (от места, где стоит игрок). */
    public int levelCost(Player player, Pillar target) {
        if (player.hasPermission("rupillars.admin")) return 0;
        if (!plugin.getConfig().getBoolean("level-cost.enabled", true)) return 0;
        Location loc = player.getLocation();
        if (!loc.getWorld().getName().equals(target.world)) {
            return Math.max(0, plugin.getConfig().getInt("level-cost.other-world", 5));
        }
        double dx = target.tx - loc.getX();
        double dy = target.ty - loc.getY();
        double dz = target.tz - loc.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        List<Integer> distances = plugin.getConfig().getIntegerList("level-cost.distances");
        List<Integer> levels = plugin.getConfig().getIntegerList("level-cost.levels");
        if (levels.isEmpty()) levels = List.of(1);
        for (int i = 0; i < distances.size(); i++) {
            if (dist <= distances.get(i)) return Math.max(0, levels.get(Math.min(i, levels.size() - 1)));
        }
        return Math.max(0, levels.get(Math.min(distances.size(), levels.size() - 1)));
    }

    /** Удаление метки владельцем (или админом) с возвратом денег, если он настроен. */
    public void deleteFor(Player player, Pillar p) {
        boolean mine = p.owner.equals(player.getUniqueId());
        String pname = p.name;
        String owner = p.ownerName;
        remove(p);
        double refund = plugin.getConfig().getDouble("cost", 100000) * plugin.getConfig().getDouble("refund-percent", 0) / 100.0;
        if (mine && refund > 0 && plugin.economy() != null && plugin.economy().deposit(player, refund)) {
            player.sendMessage(plugin.msg("deleted-refund", "%name%", pname, "%refund%", plugin.money(refund)));
        } else if (mine) {
            player.sendMessage(plugin.msg("deleted", "%name%", pname));
        } else {
            player.sendMessage(plugin.msg("removed-admin", "%name%", pname, "%owner%", owner));
        }
    }

    // ---------- телепорт ----------

    public void cancelWarmup(Player player, boolean notify) {
        BukkitTask task = warmups.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
            if (notify) player.sendMessage(plugin.msg("cancelled"));
        }
    }

    public boolean isWarming(Player player) {
        return warmups.containsKey(player.getUniqueId());
    }

    public void teleport(Player player, Pillar target) {
        if (!pillars.containsKey(target.id)) {
            player.sendMessage(plugin.msg("gone"));
            return;
        }
        if (!canUse(player, target)) {
            player.sendMessage(plugin.msg("closed-now"));
            return;
        }
        boolean admin = player.hasPermission("rupillars.admin");
        int levels = levelCost(player, target);
        if (levels > 0 && player.getLevel() < levels) {
            player.sendMessage(plugin.msg("no-levels", "%levels%", String.valueOf(levels),
                    "%have%", String.valueOf(player.getLevel())));
            return;
        }
        long cooldown = plugin.getConfig().getLong("cooldown-seconds", 10) * 1000L;
        Long last = lastTeleport.get(player.getUniqueId());
        if (!admin && last != null && cooldown > 0 && System.currentTimeMillis() - last < cooldown) {
            long left = (cooldown - (System.currentTimeMillis() - last) + 999) / 1000;
            player.sendMessage(plugin.msg("cooldown", "%seconds%", String.valueOf(left)));
            return;
        }
        double cost = admin ? 0 : plugin.getConfig().getDouble("teleport-cost", 0);
        if (cost > 0) {
            VaultEconomy eco = plugin.economy();
            if (eco == null) {
                player.sendMessage(plugin.msg("no-economy"));
                return;
            }
            if (!eco.has(player, cost)) {
                player.sendMessage(plugin.msg("tp-not-enough", "%cost%", plugin.money(cost)));
                return;
            }
        }
        cancelWarmup(player, false);
        int warmup = admin ? 0 : plugin.getConfig().getInt("warmup-seconds", 3);
        if (warmup <= 0) {
            finishTeleport(player, target, cost, levels);
            return;
        }
        player.sendMessage(plugin.msg("warmup", "%seconds%", String.valueOf(warmup)));
        Location start = player.getLocation().clone();
        BukkitTask task = new org.bukkit.scheduler.BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancelWarmup(player, false);
                    return;
                }
                Location now = player.getLocation();
                if (!now.getWorld().equals(start.getWorld()) || now.distanceSquared(start) > 0.6) {
                    cancelWarmup(player, true);
                    return;
                }
                ticks += 5;
                if (ticks >= warmup * 20) {
                    warmups.remove(player.getUniqueId());
                    cancel();
                    finishTeleport(player, target, cost, levels);
                }
            }
        }.runTaskTimer(plugin, 5L, 5L);
        warmups.put(player.getUniqueId(), task);
    }

    private void finishTeleport(Player player, Pillar target, double cost, int levels) {
        if (!player.isOnline()) return;
        if (!pillars.containsKey(target.id)) {
            player.sendMessage(plugin.msg("gone"));
            return;
        }
        World world = Bukkit.getWorld(target.world);
        if (world == null) {
            player.sendMessage(plugin.msg("gone"));
            return;
        }
        if (!canUse(player, target)) {
            player.sendMessage(plugin.msg("closed-now"));
            return;
        }
        if (levels > 0) {
            if (player.getLevel() < levels) {
                player.sendMessage(plugin.msg("no-levels", "%levels%", String.valueOf(levels),
                        "%have%", String.valueOf(player.getLevel())));
                return;
            }
        }
        if (cost > 0) {
            VaultEconomy eco = plugin.economy();
            if (eco == null || !eco.withdraw(player, cost)) {
                player.sendMessage(plugin.msg("tp-not-enough", "%cost%", plugin.money(cost)));
                return;
            }
            player.sendMessage(plugin.msg("tp-cost", "%cost%", plugin.money(cost)));
        }
        if (levels > 0) {
            player.setLevel(player.getLevel() - levels);
            player.sendMessage(plugin.msg("tp-levels", "%levels%", String.valueOf(levels)));
        }
        Location dest = new Location(world, target.tx, target.ty, target.tz, target.yaw, 0f);
        lastTeleport.put(player.getUniqueId(), System.currentTimeMillis());
        player.teleportAsync(dest).thenAccept(ok -> {
            if (ok) {
                Bukkit.getScheduler().runTask(plugin, () -> {
                    player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                    player.sendMessage(plugin.msg("teleported", "%name%", target.name));
                });
            }
        });
    }
}
