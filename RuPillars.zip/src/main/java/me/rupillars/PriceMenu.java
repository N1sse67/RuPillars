package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Меню цен (Java). Три строки: создание метки, телепорт (деньги), возврат при удалении (%).
 * В каждой строке кнопки -большой, -средний, -малый, значение, +малый, +средний, +большой.
 */
public final class PriceMenu implements InventoryHolder {

    private static final double[] MONEY_STEPS = {100000, 10000, 1000};
    private static final double[] PERCENT_STEPS = {10, 5, 1};

    private final PillarsPlugin plugin;
    private Inventory inventory;

    private PriceMenu(PillarsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private static Component plain(String legacy) {
        return PillarsPlugin.legacy(legacy).decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack s = new ItemStack(m);
        ItemMeta meta = s.getItemMeta();
        meta.displayName(plain(name));
        if (lore != null) {
            meta.lore(lore.stream().map(PriceMenu::plain).toList());
        }
        s.setItemMeta(meta);
        return s;
    }

    private static String num(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    public static void open(PillarsPlugin plugin, Player player) {
        PriceMenu menu = new PriceMenu(plugin);
        menu.inventory = Bukkit.createInventory(menu, 54, PillarsPlugin.legacy(plugin.raw("prices-title")));
        PillarManager pm = plugin.manager();
        menu.row(9, "price-create", Material.GOLD_INGOT, pm.cost(), MONEY_STEPS, false);
        menu.row(18, "price-teleport", Material.ENDER_PEARL, pm.teleportCost(), MONEY_STEPS, false);
        menu.row(27, "price-refund", Material.EMERALD, pm.refundPercent(), PERCENT_STEPS, true);
        menu.inventory.setItem(49, item(Material.ARROW, plugin.raw("manage-back"), null));
        player.openInventory(menu.inventory);
    }

    private void row(int start, String key, Material icon, double value, double[] steps, boolean percent) {
        String shown = percent ? num(value) + "%" : plugin.money(value);
        inventory.setItem(start + 4, item(icon, plugin.raw(key),
                List.of(PillarsPlugin.fill(plugin.raw("price-now"), "%value%", shown))));
        for (int i = 0; i < 3; i++) {
            String s = percent ? num(steps[i]) + "%" : num(steps[i]);
            inventory.setItem(start + i, item(Material.RED_STAINED_GLASS_PANE, "&c-" + s, null));
            inventory.setItem(start + 6 + (2 - i), item(Material.LIME_STAINED_GLASS_PANE, "&a+" + s, null));
        }
    }

    public void click(Player player, int slot) {
        PillarManager pm = plugin.manager();
        if (slot == 49) {
            AdminMenu.openList(plugin, player, 0);
            return;
        }
        int rowStart = slot >= 9 && slot < 18 ? 9 : slot >= 18 && slot < 27 ? 18 : slot >= 27 && slot < 36 ? 27 : -1;
        if (rowStart < 0) return;
        int col = slot - rowStart;
        if (col == 3 || col == 4 || col == 5 || col > 8) return;
        boolean minus = col < 3;
        int stepIndex = minus ? col : 8 - col;
        double sign = minus ? -1 : 1;
        if (rowStart == 9) {
            pm.setCost(pm.cost() + sign * MONEY_STEPS[stepIndex]);
        } else if (rowStart == 18) {
            pm.setTeleportCost(pm.teleportCost() + sign * MONEY_STEPS[stepIndex]);
        } else {
            pm.setRefundPercent(pm.refundPercent() + sign * PERCENT_STEPS[stepIndex]);
        }
        open(plugin, player);
    }
}
