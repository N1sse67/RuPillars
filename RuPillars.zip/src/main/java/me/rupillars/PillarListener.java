package me.rupillars;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.view.AnvilView;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

public final class PillarListener implements Listener {

    private final PillarsPlugin plugin;

    public PillarListener(PillarsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) return;
        Block block = e.getClickedBlock();
        if (block == null) return;
        Pillar p = plugin.manager().atBlock(block);
        if (p == null) return;
        Player player = e.getPlayer();
        if (player.isSneaking()) return;
        e.setCancelled(true);
        if (!player.hasPermission("rupillars.use")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }
        if (!plugin.manager().canUse(player, p)) {
            player.sendMessage(plugin.msg("closed-now"));
            return;
        }
        plugin.openMenu(player, p);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        Pillar p = plugin.manager().atBlock(e.getBlock());
        if (p == null) return;
        e.setCancelled(true);
        Player player = e.getPlayer();
        if (player.hasPermission("rupillars.admin") && player.isSneaking()) {
            String name = p.name;
            String owner = p.ownerName;
            plugin.manager().remove(p);
            player.sendMessage(plugin.msg("removed-admin", "%name%", name, "%owner%", owner));
        } else {
            player.sendMessage(plugin.msg("protected"));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.manager().isPillarBlock(b));
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.manager().isPillarBlock(b));
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (plugin.manager().isPillarBlock(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (plugin.manager().isPillarBlock(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onChange(EntityChangeBlockEvent e) {
        if (plugin.manager().isPillarBlock(e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof PillarMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        menu.click(player, e.getSlot());
    }

    @EventHandler(ignoreCancelled = true)
    public void onManageClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof ManageMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player player)) return;
        if (e.getClickedInventory() != e.getView().getTopInventory()) return;
        menu.click(player, e.getSlot(), e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT,
                e.getClick() == ClickType.SHIFT_LEFT);
    }

    @EventHandler(ignoreCancelled = true)
    public void onAdminClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        var holder = e.getView().getTopInventory().getHolder();
        if (holder instanceof AccessMenu am) {
            e.setCancelled(true);
            if (e.getClickedInventory() == e.getView().getTopInventory()) am.click(player, e.getSlot());
            return;
        }
        if (holder instanceof AdminMenu || holder instanceof PriceMenu) {
            e.setCancelled(true);
            if (!player.hasPermission("rupillars.admin")) {
                player.closeInventory();
                return;
            }
            if (e.getClickedInventory() != e.getView().getTopInventory()) return;
            if (holder instanceof AdminMenu m) m.click(player, e.getSlot());
            else if (holder instanceof PriceMenu m) m.click(player, e.getSlot());
            return;
        }

        // Наковальня для ввода текста (переименование метки)
        if (!plugin.prompts().containsKey(player.getUniqueId())
                || e.getView().getTopInventory().getType() != InventoryType.ANVIL) return;
        e.setCancelled(true);
        if (e.getRawSlot() != 2 || !(e.getView() instanceof AnvilView view)) return;
        String text = view.getRenameText();
        if (text == null || text.isBlank()) text = plugin.promptStart(player.getUniqueId());
        var callback = plugin.prompts().remove(player.getUniqueId());
        e.getView().getTopInventory().clear();
        player.closeInventory();
        if (callback != null) {
            final String result = text;
            org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> callback.accept(result));
        }
    }

    @EventHandler
    public void onPrepare(PrepareAnvilEvent e) {
        if (!(e.getView().getPlayer() instanceof Player player)) return;
        if (!plugin.prompts().containsKey(player.getUniqueId())) return;
        String text = e.getView().getRenameText();
        if (text == null || text.isBlank()) text = plugin.promptStart(player.getUniqueId());
        org.bukkit.inventory.ItemStack result = new org.bukkit.inventory.ItemStack(org.bukkit.Material.LIME_DYE);
        org.bukkit.inventory.meta.ItemMeta meta = result.getItemMeta();
        meta.displayName(net.kyori.adventure.text.Component.text(text));
        result.setItemMeta(meta);
        e.setResult(result);
        e.getView().setRepairCost(0);
    }

    @EventHandler
    public void onAnvilClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player player)) return;
        if (plugin.prompts().remove(player.getUniqueId()) != null && e.getInventory().getType() == InventoryType.ANVIL) {
            e.getInventory().clear();
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        var h = e.getView().getTopInventory().getHolder();
        if (h instanceof PillarMenu || h instanceof ManageMenu || h instanceof AdminMenu || h instanceof PriceMenu || h instanceof AccessMenu) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player player && plugin.manager().isWarming(player)) {
            plugin.manager().cancelWarmup(player, true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.manager().cancelWarmup(e.getPlayer(), false);
    }
}
