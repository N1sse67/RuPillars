package me.rupillars;

import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class PillarCommand implements CommandExecutor, TabCompleter {

    private final PillarsPlugin plugin;

    public PillarCommand(PillarsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);

        if (sub.equals("reload")) {
            if (!sender.hasPermission("rupillars.admin")) {
                sender.sendMessage(plugin.msg("no-permission"));
                return true;
            }
            plugin.reload();
            sender.sendMessage(plugin.msg("reloaded"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.msg("players-only"));
            return true;
        }

        switch (sub) {
            case "" , "menu", "меню" -> openMenu(player);
            case "create", "new", "создать", "поставить" -> create(player, args);
            case "delete", "remove", "удалить" -> delete(player, args);
            case "list", "список" -> list(player);
            case "access", "доступ" -> access(player, args);
            case "manage", "управление", "мои" -> plugin.openManage(player);
            default -> help(player);
        }
        return true;
    }

    private void help(Player player) {
        player.sendMessage(plugin.text("help-title"));
        for (String line : plugin.getConfig().getStringList("messages.help-lines")) {
            player.sendMessage(PillarsPlugin.legacy(line));
        }
    }

    private void openMenu(Player player) {
        PillarManager pm = plugin.manager();
        Pillar near = pm.nearest(player, plugin.getConfig().getDouble("near-radius", 6));
        if (near == null && !plugin.getConfig().getBoolean("command-anywhere", false)
                && !player.hasPermission("rupillars.admin")) {
            player.sendMessage(plugin.msg("need-near", "%radius%",
                    String.valueOf((int) plugin.getConfig().getDouble("near-radius", 6))));
            return;
        }
        plugin.openMenu(player, near);
    }

    private static String cleanName(String raw) {
        String s = raw.replaceAll("(?i)[&§][0-9a-fk-or]", "").trim();
        return s;
    }

    private void create(Player player, String[] args) {
        if (!player.hasPermission("rupillars.create")) {
            player.sendMessage(plugin.msg("no-permission"));
            return;
        }
        PillarManager pm = plugin.manager();
        boolean admin = player.hasPermission("rupillars.admin");
        List<Pillar> own = pm.ownedBy(player.getUniqueId());

        int max = plugin.getConfig().getInt("max-per-player", 5);
        if (!admin && max > 0 && own.size() >= max) {
            player.sendMessage(plugin.msg("limit", "%max%", String.valueOf(max)));
            return;
        }

        String name;
        if (args.length >= 2) {
            name = cleanName(String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)));
        } else {
            int n = own.size() + 1;
            name = "Метка " + n;
            while (pm.findOwned(player.getUniqueId(), name) != null) name = "Метка " + (++n);
        }
        if (name.isEmpty() || name.length() > 24) {
            player.sendMessage(plugin.msg("name-bad"));
            return;
        }
        if (pm.findOwned(player.getUniqueId(), name) != null) {
            player.sendMessage(plugin.msg("name-taken", "%name%", name));
            return;
        }

        Block base = pm.placementBase(player);
        if (base == null) {
            player.sendMessage(plugin.msg("no-space", "%height%", String.valueOf(pm.height())));
            return;
        }

        double cost = admin ? 0 : plugin.getConfig().getDouble("cost", 100000);
        if (cost > 0) {
            VaultEconomy eco = plugin.economy();
            if (eco == null) {
                player.sendMessage(plugin.msg("no-economy"));
                return;
            }
            if (!eco.has(player, cost)) {
                player.sendMessage(plugin.msg("not-enough", "%cost%", plugin.money(cost)));
                return;
            }
            if (!eco.withdraw(player, cost)) {
                player.sendMessage(plugin.msg("not-enough", "%cost%", plugin.money(cost)));
                return;
            }
        }

        pm.create(player, name, base);
        player.sendMessage(plugin.msg("created", "%name%", name, "%cost%", plugin.money(cost)));
    }

    private void delete(Player player, String[] args) {
        if (args.length < 2) {
            player.sendMessage(plugin.msg("usage-delete"));
            return;
        }
        PillarManager pm = plugin.manager();
        String name = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)).trim();
        Pillar p = pm.findOwned(player.getUniqueId(), name);
        boolean admin = player.hasPermission("rupillars.admin");
        if (p == null && admin) p = pm.findAny(name);
        if (p == null) {
            player.sendMessage(plugin.msg("not-found", "%name%", name));
            return;
        }
        if (!p.owner.equals(player.getUniqueId()) && !admin) {
            player.sendMessage(plugin.msg("not-owner"));
            return;
        }
        pm.deleteFor(player, p);
    }

    private void access(Player player, String[] args) {
        if (args.length < 2) {
            plugin.openManage(player);
            return;
        }
        String name = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length)).trim();
        Pillar p = plugin.manager().findOwned(player.getUniqueId(), name);
        if (p == null) {
            player.sendMessage(plugin.msg("not-found", "%name%", name));
            return;
        }
        p.open = !p.open;
        plugin.manager().save();
        player.sendMessage(plugin.msg(p.open ? "now-open" : "now-closed", "%name%", p.name));
    }

    private void list(Player player) {
        List<Pillar> own = plugin.manager().ownedBy(player.getUniqueId());
        if (own.isEmpty()) {
            player.sendMessage(plugin.text("empty"));
            return;
        }
        player.sendMessage(plugin.text("list-title"));
        int n = 1;
        for (Pillar p : own) {
            player.sendMessage(plugin.text("list-line", "%n%", String.valueOf(n++), "%name%", p.name,
                    "%world%", p.world, "%x%", String.valueOf(p.bx), "%y%", String.valueOf(p.by), "%z%", String.valueOf(p.bz)));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : new String[]{"создать", "удалить", "доступ", "управление", "список", "меню", "reload"}) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && sender instanceof Player p
                && (args[0].equalsIgnoreCase("удалить") || args[0].equalsIgnoreCase("delete") || args[0].equalsIgnoreCase("доступ"))) {
            for (Pillar pl : plugin.manager().ownedBy(p.getUniqueId())) {
                if (pl.name.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(pl.name);
            }
        }
        return out;
    }
}
