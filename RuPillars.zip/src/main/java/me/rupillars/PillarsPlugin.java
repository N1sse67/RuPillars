package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class PillarsPlugin extends JavaPlugin {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private PillarManager manager;
    private VaultEconomy economy;
    private BedrockHook bedrock;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new PillarManager(this);
        manager.load();

        getServer().getPluginManager().registerEvents(new PillarListener(this), this);
        PillarCommand handler = new PillarCommand(this);
        PluginCommand command = getCommand("pillar");
        if (command != null) {
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        Bukkit.getScheduler().runTaskLater(this, () -> manager.refreshHolograms(), 40L);
        getLogger().info("RuPillars включён. Меток: " + manager.count());
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.save();
    }

    public void reload() {
        reloadConfig();
        manager.load();
        manager.refreshHolograms();
    }

    public PillarManager manager() {
        return manager;
    }

    public VaultEconomy economy() {
        if (economy == null) economy = VaultEconomy.hook();
        return economy;
    }

    public BedrockHook bedrock() {
        if (bedrock == null && getServer().getPluginManager().isPluginEnabled("floodgate")) {
            try {
                bedrock = new BedrockHook(this);
            } catch (Throwable t) {
                getLogger().warning("Floodgate найден, но подключиться не удалось: " + t);
            }
        }
        return bedrock;
    }

    public boolean isBedrock(Player player) {
        BedrockHook hook = bedrock();
        return hook != null && hook.isBedrock(player.getUniqueId());
    }

    /** Открыть меню меток: форма для Bedrock или сундук для Java. from — метка, у которой стоит игрок (может быть null). */
    public void openMenu(Player player, Pillar from) {
        if (isBedrock(player)) {
            bedrock().open(player, from);
        } else {
            PillarMenu.open(this, player, from, 0);
        }
    }

    /** Меню управления своими метками (открыть/закрыть доступ, удалить). */
    public void openManage(Player player) {
        if (isBedrock(player)) {
            bedrock().openManage(player);
        } else {
            ManageMenu.open(this, player);
        }
    }

    // ---------- админ-меню и ввод текста в наковальне ----------

    private final java.util.Map<java.util.UUID, java.util.function.Consumer<String>> prompts = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Map<java.util.UUID, String> promptStart = new java.util.concurrent.ConcurrentHashMap<>();

    public java.util.Map<java.util.UUID, java.util.function.Consumer<String>> prompts() {
        return prompts;
    }

    public String promptStart(java.util.UUID id) {
        return promptStart.getOrDefault(id, "");
    }

    /** Открыть наковальню: игрок вписывает текст и нажимает на результат справа. */
    public void openPrompt(Player player, String title, String start, java.util.function.Consumer<String> callback) {
        prompts.put(player.getUniqueId(), callback);
        promptStart.put(player.getUniqueId(), start);
        org.bukkit.inventory.InventoryView view = org.bukkit.inventory.MenuType.ANVIL.create(player, Component.text(title));
        org.bukkit.inventory.ItemStack paper = new org.bukkit.inventory.ItemStack(org.bukkit.Material.PAPER);
        org.bukkit.inventory.meta.ItemMeta meta = paper.getItemMeta();
        meta.displayName(Component.text(start));
        paper.setItemMeta(meta);
        view.getTopInventory().setItem(0, paper);
        player.openInventory(view);
    }

    /** Админ-меню: все метки сервера, цены. */
    public void openAdmin(Player player) {
        if (isBedrock(player)) {
            bedrock().openAdmin(player);
        } else {
            AdminMenu.openList(this, player, 0);
        }
    }

    public void openPrices(Player player) {
        if (isBedrock(player)) {
            bedrock().openPrices(player);
        } else {
            PriceMenu.open(this, player);
        }
    }

    /** Переименование метки (из меню): вписать новое название. */
    public void promptRename(Player player, Pillar p) {
        if (isBedrock(player)) {
            bedrock().openRename(player, p);
        } else {
            openPrompt(player, raw("rename-title"), p.name, text -> applyRename(player, p, text));
        }
    }

    public void applyRename(Player player, Pillar p, String raw) {
        String name = raw == null ? "" : raw.replaceAll("(?i)[&§][0-9a-fk-or]", "").trim();
        if (manager.byId(p.id) == null) {
            player.sendMessage(msg("gone"));
            return;
        }
        String error = manager.checkName(p, name);
        if (error != null) {
            player.sendMessage(msg(error, "%name%", name));
            return;
        }
        String old = p.name;
        manager.rename(p, name);
        player.sendMessage(msg("renamed", "%old%", old, "%new%", name));
    }

    /** Выдать или забрать доступ к своей метке у выбранного игрока. */
    public void applyAccess(Player owner, Pillar p, org.bukkit.OfflinePlayer target, boolean give) {
        if (manager.byId(p.id) == null) {
            owner.sendMessage(msg("gone"));
            return;
        }
        if (!p.owner.equals(owner.getUniqueId()) && !owner.hasPermission("rupillars.admin")) {
            owner.sendMessage(msg("not-owner"));
            return;
        }
        String name = String.valueOf(target.getName());
        if (target.getUniqueId().equals(p.owner)) {
            owner.sendMessage(msg("access-self"));
            return;
        }
        boolean changed = manager.setAccess(p, target.getUniqueId(), give);
        if (give) {
            owner.sendMessage(msg(changed ? "access-given" : "access-already", "%player%", name, "%name%", p.name));
            Player online = target.getPlayer();
            if (changed && online != null) online.sendMessage(msg("access-notify", "%owner%", p.ownerName, "%name%", p.name));
        } else {
            owner.sendMessage(msg(changed ? "access-taken" : "access-not-had", "%player%", name, "%name%", p.name));
        }
    }

    public String money(double amount) {
        VaultEconomy eco = economy();
        return eco != null ? eco.format(amount) : String.valueOf((long) amount);
    }

    public String raw(String key) {
        return getConfig().getString("messages." + key, key);
    }

    public Component msg(String key, String... replacements) {
        return LEGACY.deserialize(raw("prefix") + fill(raw(key), replacements));
    }

    public Component text(String key, String... replacements) {
        return LEGACY.deserialize(fill(raw(key), replacements));
    }

    public static String fill(String text, String... replacements) {
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace(replacements[i], replacements[i + 1]);
        }
        return text;
    }

    public static Component legacy(String text) {
        return LEGACY.deserialize(text);
    }
}
