package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class PillarsPlugin extends JavaPlugin {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private PillarManager manager;
    private VaultEconomy economy;
    private BedrockHook bedrock;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new PillarManager(this);
        manager.load();

        getServer().getPluginManager().registerEvents(new PillarListener(this), this);
        PillarCommand handler = new PillarCommand(this);
        PluginCommand command = getCommand("pillar");
        if (command != null) {
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }
        getLogger().info("RuPillars включён. Меток: " + manager.count());
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.save();
    }

    public void reload() {
        reloadConfig();
        manager.load();
    }

    public PillarManager manager() {
        return manager;
    }

    public VaultEconomy economy() {
        if (economy == null) economy = VaultEconomy.hook();
        return economy;
    }

    public BedrockHook bedrock() {
        if (bedrock == null && getServer().getPluginManager().isPluginEnabled("floodgate")) {
            try {
                bedrock = new BedrockHook(this);
            } catch (Throwable t) {
                getLogger().warning("Floodgate найден, но подключиться не удалось: " + t);
            }
        }
        return bedrock;
    }

    public boolean isBedrock(Player player) {
        BedrockHook hook = bedrock();
        return hook != null && hook.isBedrock(player.getUniqueId());
    }

    /** Открыть меню меток: форма для Bedrock или сундук для Java. from — метка, у которой стоит игрок (может быть null). */
    public void openMenu(Player player, Pillar from) {
        if (isBedrock(player)) {
            bedrock().open(player, from);
        } else {
            PillarMenu.open(this, player, from, 0);
        }
    }

    /** Меню управления своими метками (открыть/закрыть доступ, удалить). */
    public void openManage(Player player) {
        if (isBedrock(player)) {
            bedrock().openManage(player);
        } else {
            ManageMenu.open(this, player);
        }
    }

    public String money(double amount) {
        VaultEconomy eco = economy();
        return eco != null ? eco.format(amount) : String.valueOf((long) amount);
    }

    public String raw(String key) {
        return getConfig().getString("messages." + key, key);
    }

    public Component msg(String key, String... replacements) {
        return LEGACY.deserialize(raw("prefix") + fill(raw(key), replacements));
    }

    public Component text(String key, String... replacements) {
        return LEGACY.deserialize(fill(raw(key), replacements));
    }

    public static String fill(String text, String... replacements) {
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace(replacements[i], replacements[i + 1]);
        }
        return text;
    }

    public static Component legacy(String text) {
        return LEGACY.deserialize(text);
    }
}
