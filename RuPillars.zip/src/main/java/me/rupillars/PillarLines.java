package me.rupillars;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Описание метки для меню и форм. */
final class PillarLines {

    private PillarLines() {
    }

    static List<String> lines(PillarsPlugin plugin, Player player, Pillar p) {
        List<String> out = new ArrayList<>();
        out.add(PillarsPlugin.fill(plugin.raw("item-owner"), "%owner%", p.ownerName));
        out.add(PillarsPlugin.fill(plugin.raw("item-place"), "%world%", p.world,
                "%x%", String.valueOf((int) p.tx), "%y%", String.valueOf((int) p.ty), "%z%", String.valueOf((int) p.tz)));
        Location loc = player.getLocation();
        if (loc.getWorld().getName().equals(p.world)) {
            double dx = p.tx - loc.getX();
            double dy = p.ty - loc.getY();
            double dz = p.tz - loc.getZ();
            out.add(PillarsPlugin.fill(plugin.raw("item-distance"),
                    "%distance%", String.valueOf((int) Math.sqrt(dx * dx + dy * dy + dz * dz))));
        } else {
            out.add(plugin.raw("item-other-world"));
        }
        int levels = plugin.manager().levelCost(player, p);
        if (levels > 0) {
            out.add(PillarsPlugin.fill(plugin.raw(player.getLevel() >= levels ? "item-levels" : "item-levels-low"),
                    "%levels%", String.valueOf(levels)));
        }
        double cost = player.hasPermission("rupillars.admin") ? 0 : plugin.getConfig().getDouble("teleport-cost", 0);
        if (cost > 0) out.add(PillarsPlugin.fill(plugin.raw("item-cost"), "%cost%", plugin.money(cost)));
        out.add(plugin.raw("item-click"));
        return out;
    }
}
