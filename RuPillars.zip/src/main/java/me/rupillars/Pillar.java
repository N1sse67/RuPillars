package me.rupillars;

import java.util.UUID;

/** Одна метка-столб. */
public final class Pillar {
    public String id;
    public UUID owner;
    public String ownerName;
    public String name;
    public String world;
    /** Нижний блок столба. */
    public int bx, by, bz;
    /** Точка телепорта (где стоял игрок при создании). */
    public double tx, ty, tz;
    public float yaw;
    /** true: меткой могут пользоваться все; false: только владелец. */
    public boolean open = true;
}
