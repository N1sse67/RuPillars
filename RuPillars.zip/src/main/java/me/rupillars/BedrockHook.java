package me.rupillars;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Форма для игроков с Bedrock через Floodgate. Класс загружается только если Floodgate установлен. */
public final class BedrockHook {

    private final PillarsPlugin plugin;

    public BedrockHook(PillarsPlugin plugin) {
        this.plugin = plugin;
        FloodgateApi.getInstance();
    }

    public boolean isBedrock(UUID id) {
        return FloodgateApi.getInstance().isFloodgatePlayer(id);
    }

    private String c(String text) {
        String s = text.replace('&', '§');
        if (!plugin.getConfig().getBoolean("bedrock-text-black", true)) return s;
        s = s.replaceAll("(?i)§[0-9a-fr]", "");
        return "§0" + s.replace("\n", "\n§0");
    }

    public void open(Player player, Pillar from) {
        List<Pillar> list = new ArrayList<>(plugin.manager().visibleFor(player));
        if (from != null) list.removeIf(p -> p.id.equals(from.id));
        boolean hasOwn = !plugin.manager().ownedBy(player.getUniqueId()).isEmpty();
        if (list.isEmpty() && !hasOwn) {
            player.sendMessage(plugin.text("empty"));
            return;
        }

        String title = from == null ? plugin.raw("form-title")
                : PillarsPlugin.fill(plugin.raw("menu-title-from"), "%name%", from.name);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(title))
                .content(c(plugin.raw("form-hint")));

        for (Pillar p : list) {
            String sub = p.world.equals(player.getWorld().getName())
                    ? (int) distance(player, p) + " м · " + p.ownerName
                    : p.world + " · " + p.ownerName;
            int levels = plugin.manager().levelCost(player, p);
            if (levels > 0) sub += " · " + levels + " ур.";
            form.button(c(p.name + "\n&7" + sub));
        }
        if (hasOwn) form.button(c(plugin.raw("menu-manage")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            if (id == list.size() && hasOwn) {
                Bukkit.getScheduler().runTask(plugin, () -> openManage(player));
                return;
            }
            if (id < 0 || id >= list.size()) return;
            Pillar target = list.get(id);
            Bukkit.getScheduler().runTask(plugin, () -> plugin.manager().teleport(player, target));
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    /** Список своих меток: нажмите на метку, чтобы изменить доступ или удалить. */
    public void openManage(Player player) {
        List<Pillar> own = new ArrayList<>(plugin.manager().ownedBy(player.getUniqueId()));
        if (own.isEmpty()) {
            player.sendMessage(plugin.text("empty"));
            return;
        }
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(plugin.raw("manage-title")))
                .content(c(plugin.raw("manage-form-hint")));
        for (Pillar p : own) {
            form.button(c(p.name + "\n" + plugin.raw(p.open ? "state-open" : "state-closed")));
        }
        form.button(c(plugin.raw("manage-back")));
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id < 0 || id >= own.size()) {
                    plugin.openMenu(player, plugin.manager().nearest(player, plugin.getConfig().getDouble("near-radius", 6)));
                } else {
                    openOne(player, own.get(id));
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    private void openOne(Player player, Pillar p) {
        if (plugin.manager().byId(p.id) == null) {
            openManage(player);
            return;
        }
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(p.name))
                .content(c(plugin.raw(p.open ? "state-open" : "state-closed")));
        form.button(c(plugin.raw(p.open ? "form-close" : "form-open")));
        form.button(c(plugin.raw("form-delete")));
        form.button(c(plugin.raw("manage-back")));
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (plugin.manager().byId(p.id) == null) {
                    openManage(player);
                    return;
                }
                if (id == 0) {
                    p.open = !p.open;
                    plugin.manager().save();
                    player.sendMessage(plugin.msg(p.open ? "now-open" : "now-closed", "%name%", p.name));
                } else if (id == 1) {
                    plugin.manager().deleteFor(player, p);
                }
                openManage(player);
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    private static double distance(Player player, Pillar p) {
        double dx = p.tx - player.getLocation().getX();
        double dy = p.ty - player.getLocation().getY();
        double dz = p.tz - player.getLocation().getZ();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
