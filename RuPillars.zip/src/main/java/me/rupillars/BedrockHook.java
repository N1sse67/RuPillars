package me.rupillars;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.geysermc.cumulus.form.SimpleForm;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Форма для игроков с Bedrock через Floodgate. Класс загружается только если Floodgate установлен. */
public final class BedrockHook {

    private final PillarsPlugin plugin;

    public BedrockHook(PillarsPlugin plugin) {
        this.plugin = plugin;
        FloodgateApi.getInstance();
    }

    public boolean isBedrock(UUID id) {
        return FloodgateApi.getInstance().isFloodgatePlayer(id);
    }

    private String c(String text) {
        String s = text.replace('&', '§');
        if (!plugin.getConfig().getBoolean("bedrock-text-black", true)) return s;
        s = s.replaceAll("(?i)§[0-9a-fr]", "");
        return "§0" + s.replace("\n", "\n§0");
    }

    public void open(Player player, Pillar from) {
        List<Pillar> list = new ArrayList<>(plugin.manager().visibleFor(player));
        if (from != null) list.removeIf(p -> p.id.equals(from.id));
        boolean hasOwn = !plugin.manager().ownedBy(player.getUniqueId()).isEmpty();
        if (list.isEmpty() && !hasOwn) {
            player.sendMessage(plugin.text("empty"));
            return;
        }

        String title = from == null ? plugin.raw("form-title")
                : PillarsPlugin.fill(plugin.raw("menu-title-from"), "%name%", from.name);
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(title))
                .content(c(plugin.raw("form-hint")));

        for (Pillar p : list) {
            String sub = !PillarLines.canSeeCoords(plugin, player, p) ? p.ownerName
                    : p.world.equals(player.getWorld().getName())
                    ? (int) distance(player, p) + " м · " + p.ownerName
                    : p.world + " · " + p.ownerName;
            int levels = plugin.manager().levelCost(player, p);
            if (levels > 0) sub += " · " + levels + " ур.";
            form.button(c(p.name + "\n&7" + sub));
        }
        if (hasOwn) form.button(c(plugin.raw("menu-manage")));

        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            if (id == list.size() && hasOwn) {
                Bukkit.getScheduler().runTask(plugin, () -> openManage(player));
                return;
            }
            if (id < 0 || id >= list.size()) return;
            Pillar target = list.get(id);
            Bukkit.getScheduler().runTask(plugin, () -> plugin.manager().teleport(player, target));
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    /** Список своих меток: нажмите на метку, чтобы изменить доступ или удалить. */
    public void openManage(Player player) {
        List<Pillar> own = new ArrayList<>(plugin.manager().ownedBy(player.getUniqueId()));
        if (own.isEmpty()) {
            player.sendMessage(plugin.text("empty"));
            return;
        }
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(plugin.raw("manage-title")))
                .content(c(plugin.raw("manage-form-hint")));
        for (Pillar p : own) {
            form.button(c(p.name + "\n" + plugin.raw(p.open ? "state-open" : "state-closed")));
        }
        form.button(c(plugin.raw("manage-back")));
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id < 0 || id >= own.size()) {
                    plugin.openMenu(player, plugin.manager().nearest(player, plugin.getConfig().getDouble("near-radius", 6)));
                } else {
                    openOne(player, own.get(id));
                }
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    private void openOne(Player player, Pillar p) {
        if (plugin.manager().byId(p.id) == null) {
            openManage(player);
            return;
        }
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(p.name))
                .content(c(plugin.raw(p.open ? "state-open" : "state-closed")));
        form.button(c(plugin.raw(p.open ? "form-close" : "form-open")));
        form.button(c(plugin.raw("form-access")));
        form.button(c(plugin.raw("form-delete")));
        form.button(c(plugin.raw("manage-back")));
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (plugin.manager().byId(p.id) == null) {
                    openManage(player);
                    return;
                }
                if (id == 0) {
                    p.open = !p.open;
                    plugin.manager().save();
                    player.sendMessage(plugin.msg(p.open ? "now-open" : "now-closed", "%name%", p.name));
                } else if (id == 1) {
                    openAccess(player, p);
                    return;
                } else if (id == 2) {
                    plugin.manager().deleteFor(player, p);
                }
                openManage(player);
            });
        });
        FloodgateApi.getInstance().sendForm(player.getUniqueId(), form.build());
    }

    /** Доступ игроков к своей метке: выбрать онлайн-игрока или написать ник, выдать или забрать. */
    public void openAccess(Player owner, Pillar p) {
        if (plugin.manager().byId(p.id) == null) {
            openManage(owner);
            return;
        }
        List<String> online = new ArrayList<>();
        online.add(c(plugin.raw("form-access-none")));
        List<String> names = new ArrayList<>();
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (pl.getUniqueId().equals(owner.getUniqueId())) continue;
            online.add(pl.getName());
            names.add(pl.getName());
        }
        List<String> current = new ArrayList<>();
        for (UUID u : p.allowed) {
            String n = Bukkit.getOfflinePlayer(u).getName();
            current.add(n == null ? "?" : n);
        }
        String now = current.isEmpty() ? plugin.raw("form-access-nobody") : String.join(", ", current);

        CustomForm.Builder form = CustomForm.builder()
                .title(c(p.name))
                .dropdown(c(plugin.raw("form-access-action") + " (" + now + ")"),
                        c(plugin.raw("form-access-give")), c(plugin.raw("form-access-take")))
                .dropdown(c(plugin.raw("form-access-player")), online.toArray(new String[0]))
                .input(c(plugin.raw("form-access-other")), "", "");
        form.validResultHandler(response -> {
            int action = response.asDropdown(0);
            int pi = response.asDropdown(1);
            String other = response.asInput(2);
            Bukkit.getScheduler().runTask(plugin, () -> {
                org.bukkit.OfflinePlayer target = null;
                if (other != null && !other.isBlank()) {
                    target = Bukkit.getPlayerExact(other.trim());
                    if (target == null) target = Bukkit.getOfflinePlayerIfCached(other.trim());
                    if (target == null) {
                        owner.sendMessage(plugin.msg("player-not-found", "%player%", other.trim()));
                        return;
                    }
                } else if (pi >= 1 && pi - 1 < names.size()) {
                    target = Bukkit.getPlayerExact(names.get(pi - 1));
                }
                if (target == null) {
                    owner.sendMessage(plugin.msg("access-none"));
                    return;
                }
                plugin.applyAccess(owner, p, target, action == 0);
            });
        });
        FloodgateApi.getInstance().sendForm(owner.getUniqueId(), form.build());
    }

    // ---------- админ-формы ----------

    private static String num(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    /** Все метки сервера: первая кнопка «Цены», дальше метки. */
    public void openAdmin(Player admin) {
        List<Pillar> all = new ArrayList<>(plugin.manager().all());
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(plugin.raw("admin-title")))
                .content(c(plugin.raw("admin-form-hint")));
        form.button(c(plugin.raw("admin-prices")));
        for (Pillar p : all) {
            form.button(c(p.name + "\n" + p.ownerName + " · " + p.bx + " " + p.by + " " + p.bz
                    + (p.open ? "" : " · " + plugin.raw("state-closed"))));
        }
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id == 0) openPrices(admin);
                else if (id - 1 < all.size()) openAdminOne(admin, all.get(id - 1));
            });
        });
        FloodgateApi.getInstance().sendForm(admin.getUniqueId(), form.build());
    }

    private void openAdminOne(Player admin, Pillar p) {
        if (plugin.manager().byId(p.id) == null) {
            admin.sendMessage(plugin.msg("gone"));
            openAdmin(admin);
            return;
        }
        SimpleForm.Builder form = SimpleForm.builder()
                .title(c(p.name))
                .content(c(PillarsPlugin.fill(plugin.raw("item-owner"), "%owner%", p.ownerName) + "\n"
                        + p.world + " " + p.bx + " " + p.by + " " + p.bz + "\n" + plugin.raw(p.open ? "state-open" : "state-closed")));
        form.button(c(plugin.raw("admin-tp")));
        form.button(c(plugin.raw(p.open ? "admin-make-closed" : "admin-make-open")));
        form.button(c(plugin.raw("admin-rename")));
        form.button(c(plugin.raw("admin-delete")));
        form.button(c(plugin.raw("manage-back")));
        form.validResultHandler(response -> {
            int id = response.clickedButtonId();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (plugin.manager().byId(p.id) == null) {
                    openAdmin(admin);
                    return;
                }
                switch (id) {
                    case 0 -> plugin.manager().teleport(admin, p);
                    case 1 -> {
                        p.open = !p.open;
                        plugin.manager().save();
                        admin.sendMessage(plugin.msg(p.open ? "now-open" : "now-closed", "%name%", p.name));
                        openAdminOne(admin, p);
                    }
                    case 2 -> openRename(admin, p);
                    case 3 -> {
                        plugin.manager().deleteFor(admin, p);
                        openAdmin(admin);
                    }
                    default -> openAdmin(admin);
                }
            });
        });
        FloodgateApi.getInstance().sendForm(admin.getUniqueId(), form.build());
    }

    /** Переименование метки: поле ввода. */
    public void openRename(Player admin, Pillar p) {
        CustomForm.Builder form = CustomForm.builder()
                .title(c(plugin.raw("admin-rename")))
                .input(c(plugin.raw("form-rename-input")), "", p.name);
        form.validResultHandler(response -> {
            String text = response.asInput(0);
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.applyRename(admin, p, text);
                openAdminOne(admin, p);
            });
        });
        FloodgateApi.getInstance().sendForm(admin.getUniqueId(), form.build());
    }

    /** Цены: три поля с числами. */
    public void openPrices(Player admin) {
        PillarManager pm = plugin.manager();
        CustomForm.Builder form = CustomForm.builder()
                .title(c(plugin.raw("prices-title")))
                .input(c(plugin.raw("form-price-create")), "100000", num(pm.cost()))
                .input(c(plugin.raw("form-price-teleport")), "0", num(pm.teleportCost()))
                .input(c(plugin.raw("form-price-refund")), "0", num(pm.refundPercent()));
        form.validResultHandler(response -> {
            String a = response.asInput(0);
            String b = response.asInput(1);
            String r = response.asInput(2);
            Bukkit.getScheduler().runTask(plugin, () -> {
                try {
                    double create = Double.parseDouble(a.trim().replace(',', '.'));
                    double tp = Double.parseDouble(b.trim().replace(',', '.'));
                    double refund = Double.parseDouble(r.trim().replace(',', '.'));
                    pm.setCost(create);
                    pm.setTeleportCost(tp);
                    pm.setRefundPercent(refund);
                    admin.sendMessage(plugin.msg("price-set"));
                } catch (RuntimeException e) {
                    admin.sendMessage(plugin.msg("price-usage"));
                }
            });
        });
        FloodgateApi.getInstance().sendForm(admin.getUniqueId(), form.build());
    }

    private static double distance(Player player, Pillar p) {
        double dx = p.tx - player.getLocation().getX();
        double dy = p.ty - player.getLocation().getY();
        double dz = p.tz - player.getLocation().getZ();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
