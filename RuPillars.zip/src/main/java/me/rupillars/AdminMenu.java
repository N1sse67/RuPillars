package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Админ-меню (Java): список всех меток, управление выбранной меткой, переход к ценам. */
public final class AdminMenu implements InventoryHolder {

    private static final int PER_PAGE = 45;

    private final PillarsPlugin plugin;
    private final int page;
    private final String detailId;
    private final Map<Integer, String> slots = new HashMap<>();
    private Inventory inventory;

    private AdminMenu(PillarsPlugin plugin, int page, String detailId) {
        this.plugin = plugin;
        this.page = page;
        this.detailId = detailId;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private static Component plain(String legacy) {
        return PillarsPlugin.legacy(legacy).decoration(TextDecoration.ITALIC, false);
    }

    private static ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(plain(name));
        if (lore != null && !lore.isEmpty()) {
            List<Component> list = new ArrayList<>();
            for (String l : lore) list.add(plain(l));
            meta.lore(list);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    // ---------- список всех меток ----------

    public static void openList(PillarsPlugin plugin, Player player, int page) {
        List<Pillar> all = plugin.manager().all();
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        AdminMenu menu = new AdminMenu(plugin, page, null);
        menu.inventory = Bukkit.createInventory(menu, 54, PillarsPlugin.legacy(plugin.raw("admin-title")));

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < all.size(); i++) {
            Pillar p = all.get(start + i);
            List<String> lore = new ArrayList<>();
            lore.add(PillarsPlugin.fill(plugin.raw("item-owner"), "%owner%", p.ownerName));
            lore.add(PillarsPlugin.fill(plugin.raw("item-place"), "%world%", p.world,
                    "%x%", String.valueOf(p.bx), "%y%", String.valueOf(p.by), "%z%", String.valueOf(p.bz)));
            lore.add(plugin.raw(p.open ? "state-open" : "state-closed"));
            lore.add(plugin.raw("admin-click"));
            menu.inventory.setItem(i, item(p.open ? Material.ENDER_PEARL : Material.ENDER_EYE, "&a" + p.name, lore));
            menu.slots.put(i, p.id);
        }
        if (page > 0) menu.inventory.setItem(45, item(Material.ARROW, plugin.raw("menu-prev"), null));
        if (page < pages - 1) menu.inventory.setItem(53, item(Material.ARROW, plugin.raw("menu-next"), null));
        menu.inventory.setItem(47, item(Material.GOLD_INGOT, plugin.raw("admin-prices"), List.of(plugin.raw("admin-prices-lore"))));
        menu.inventory.setItem(49, item(Material.PAPER, PillarsPlugin.fill(plugin.raw("menu-info"),
                "%page%", String.valueOf(page + 1), "%pages%", String.valueOf(pages)), null));
        player.openInventory(menu.inventory);
    }

    // ---------- управление одной меткой ----------

    public static void openDetail(PillarsPlugin plugin, Player player, Pillar p) {
        AdminMenu menu = new AdminMenu(plugin, 0, p.id);
        menu.inventory = Bukkit.createInventory(menu, 27,
                PillarsPlugin.legacy(PillarsPlugin.fill(plugin.raw("admin-detail-title"), "%name%", p.name)));
        List<String> info = new ArrayList<>();
        info.add(PillarsPlugin.fill(plugin.raw("item-owner"), "%owner%", p.ownerName));
        info.add(PillarsPlugin.fill(plugin.raw("item-place"), "%world%", p.world,
                "%x%", String.valueOf(p.bx), "%y%", String.valueOf(p.by), "%z%", String.valueOf(p.bz)));
        info.add(plugin.raw(p.open ? "state-open" : "state-closed"));
        menu.inventory.setItem(4, item(Material.LODESTONE, "&f" + p.name, info));
        menu.inventory.setItem(10, item(Material.ENDER_PEARL, plugin.raw("admin-tp"), null));
        menu.inventory.setItem(12, item(p.open ? Material.RED_DYE : Material.LIME_DYE,
                plugin.raw(p.open ? "admin-make-closed" : "admin-make-open"), null));
        menu.inventory.setItem(14, item(Material.NAME_TAG, plugin.raw("admin-rename"), null));
        menu.inventory.setItem(16, item(Material.TNT, plugin.raw("admin-delete"), null));
        menu.inventory.setItem(22, item(Material.ARROW, plugin.raw("manage-back"), null));
        player.openInventory(menu.inventory);
    }

    public void click(Player player, int slot) {
        if (detailId == null) {
            if (slot == 45 && page > 0) {
                openList(plugin, player, page - 1);
            } else if (slot == 53) {
                openList(plugin, player, page + 1);
            } else if (slot == 47) {
                PriceMenu.open(plugin, player);
            } else {
                String id = slots.get(slot);
                if (id == null) return;
                Pillar p = plugin.manager().byId(id);
                if (p == null) {
                    player.sendMessage(plugin.msg("gone"));
                    openList(plugin, player, page);
                    return;
                }
                openDetail(plugin, player, p);
            }
            return;
        }

        Pillar p = plugin.manager().byId(detailId);
        if (p == null) {
            player.sendMessage(plugin.msg("gone"));
            openList(plugin, player, 0);
            return;
        }
        switch (slot) {
            case 10 -> {
                player.closeInventory();
                plugin.manager().teleport(player, p);
            }
            case 12 -> {
                p.open = !p.open;
                plugin.manager().save();
                player.sendMessage(plugin.msg(p.open ? "now-open" : "now-closed", "%name%", p.name));
                openDetail(plugin, player, p);
            }
            case 14 -> {
                player.closeInventory();
                Bukkit.getScheduler().runTask(plugin, () -> plugin.promptRename(player, p));
            }
            case 16 -> {
                plugin.manager().deleteFor(player, p);
                openList(plugin, player, 0);
            }
            case 22 -> openList(plugin, player, 0);
            default -> {
            }
        }
    }
}
