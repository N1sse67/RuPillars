package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Меню меток в виде сундука (для Java). */
public final class PillarMenu implements InventoryHolder {

    private static final int PER_PAGE = 45;

    private final PillarsPlugin plugin;
    private final Pillar from;
    private final int page;
    private final Map<Integer, String> slots = new HashMap<>();
    private Inventory inventory;

    private PillarMenu(PillarsPlugin plugin, Pillar from, int page) {
        this.plugin = plugin;
        this.from = from;
        this.page = page;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public static void open(PillarsPlugin plugin, Player player, Pillar from, int page) {
        List<Pillar> list = new ArrayList<>(plugin.manager().visibleFor(player));
        if (from != null) list.removeIf(p -> p.id.equals(from.id));

        int pages = Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));

        PillarMenu menu = new PillarMenu(plugin, from, page);
        String title = from == null ? plugin.raw("menu-title")
                : PillarsPlugin.fill(plugin.raw("menu-title-from"), "%name%", from.name);
        menu.inventory = Bukkit.createInventory(menu, 54, PillarsPlugin.legacy(title));

        if (list.isEmpty()) {
            player.sendMessage(plugin.text("empty"));
        }

        Material icon = Material.matchMaterial(plugin.getConfig().getString("menu-icon", "ENDER_PEARL"));
        if (icon == null) icon = Material.ENDER_PEARL;

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < list.size(); i++) {
            Pillar p = list.get(start + i);
            menu.inventory.setItem(i, item(plugin, player, p, icon));
            menu.slots.put(i, p.id);
        }

        if (page > 0) menu.inventory.setItem(45, named(Material.ARROW, plugin.raw("menu-prev")));
        if (page < pages - 1) menu.inventory.setItem(53, named(Material.ARROW, plugin.raw("menu-next")));
        menu.inventory.setItem(47, named(Material.WRITABLE_BOOK, plugin.raw("menu-manage")));
        menu.inventory.setItem(49, named(Material.PAPER, PillarsPlugin.fill(plugin.raw("menu-info"),
                "%page%", String.valueOf(page + 1), "%pages%", String.valueOf(pages))));

        player.openInventory(menu.inventory);
    }

    private static ItemStack named(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(PillarsPlugin.legacy(name).decoration(TextDecoration.ITALIC, false));
        stack.setItemMeta(meta);
        return stack;
    }

    private static ItemStack item(PillarsPlugin plugin, Player player, Pillar p, Material icon) {
        ItemStack stack = new ItemStack(icon);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(PillarsPlugin.legacy("&a" + p.name).decoration(TextDecoration.ITALIC, false));
        List<Component> lore = new ArrayList<>();
        for (String line : PillarLines.lines(plugin, player, p)) {
            lore.add(PillarsPlugin.legacy(line).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Нажатие в меню. */
    public void click(Player player, int slot) {
        if (slot == 47) {
            ManageMenu.open(plugin, player);
            return;
        }
        if (slot == 45 && page > 0) {
            open(plugin, player, from, page - 1);
            return;
        }
        if (slot == 53) {
            open(plugin, player, from, page + 1);
            return;
        }
        String id = slots.get(slot);
        if (id == null) return;
        Pillar target = plugin.manager().byId(id);
        player.closeInventory();
        if (target == null) {
            player.sendMessage(plugin.msg("gone"));
            return;
        }
        plugin.manager().teleport(player, target);
    }
}
