package me.rupillars;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Меню «Мои метки»: левый клик открывает/закрывает доступ другим игрокам, правый клик удаляет метку. */
public final class ManageMenu implements InventoryHolder {

    private final PillarsPlugin plugin;
    private final Map<Integer, String> slots = new HashMap<>();
    private Inventory inventory;

    private ManageMenu(PillarsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public static void open(PillarsPlugin plugin, Player player) {
        List<Pillar> own = plugin.manager().ownedBy(player.getUniqueId());
        if (own.isEmpty()) {
            player.sendMessage(plugin.text("empty"));
            return;
        }
        ManageMenu menu = new ManageMenu(plugin);
        menu.inventory = Bukkit.createInventory(menu, 54, PillarsPlugin.legacy(plugin.raw("manage-title")));
        for (int i = 0; i < own.size() && i < 45; i++) {
            Pillar p = own.get(i);
            Material icon = p.open ? Material.LIME_DYE : Material.RED_DYE;
            ItemStack stack = new ItemStack(icon);
            ItemMeta meta = stack.getItemMeta();
            meta.displayName(PillarsPlugin.legacy("&f" + p.name).decoration(TextDecoration.ITALIC, false));
            List<Component> lore = new ArrayList<>();
            lore.add(PillarsPlugin.legacy(plugin.raw(p.open ? "state-open" : "state-closed")).decoration(TextDecoration.ITALIC, false));
            lore.add(PillarsPlugin.legacy(PillarsPlugin.fill(plugin.raw("item-place"), "%world%", p.world,
                    "%x%", String.valueOf(p.bx), "%y%", String.valueOf(p.by), "%z%", String.valueOf(p.bz)))
                    .decoration(TextDecoration.ITALIC, false));
            for (String line : plugin.getConfig().getStringList("messages.manage-hints")) {
                lore.add(PillarsPlugin.legacy(line).decoration(TextDecoration.ITALIC, false));
            }
            meta.lore(lore);
            stack.setItemMeta(meta);
            menu.inventory.setItem(i, stack);
            menu.slots.put(i, p.id);
        }
        ItemStack back = new ItemStack(Material.ARROW);
        ItemMeta bm = back.getItemMeta();
        bm.displayName(PillarsPlugin.legacy(plugin.raw("manage-back")).decoration(TextDecoration.ITALIC, false));
        back.setItemMeta(bm);
        menu.inventory.setItem(49, back);
        player.openInventory(menu.inventory);
    }

    public void click(Player player, int slot, boolean rightClick, boolean shiftLeft) {
        if (slot == 49) {
            plugin.openMenu(player, plugin.manager().nearest(player, plugin.getConfig().getDouble("near-radius", 6)));
            return;
        }
        String id = slots.get(slot);
        if (id == null) return;
        Pillar p = plugin.manager().byId(id);
        if (p == null || !p.owner.equals(player.getUniqueId())) return;
        if (shiftLeft) {
            AccessMenu.open(plugin, player, p);
            return;
        }
        if (rightClick) {
            plugin.manager().deleteFor(player, p);
        } else {
            p.open = !p.open;
            plugin.manager().save();
            player.sendMessage(plugin.msg(p.open ? "now-open" : "now-closed", "%name%", p.name));
        }
        open(plugin, player);
    }
}
